import Image from 'next/image'

export default function Home() {
  return (
    <div 
      className="min-h-screen bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: 'url("https://hebbkx1anhila5yf.public.blob.vercel-storage.com/modified_background_image-35EBmw390qldclCP6hj3LNxPPOC6I1.png")',
      }}
    >
      <div className="container mx-auto px-6 py-12">
        <div className="bg-white/95 backdrop-blur-sm rounded-lg shadow-md p-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4 text-blue-800">Welcome to Willkings Healthcare Pvt. Ltd.</h1>
            <p className="text-xl mb-8 text-gray-600">Providing quality healthcare products and services</p>
          </div>
          <div className="mb-8">
            <p className="text-gray-700">
              At Willkings Healthcare, we are dedicated to providing exceptional and compassionate healthcare services. With a commitment to improving the health and well-being of individuals, our mission is to offer high-quality medical care that is accessible, affordable, and personalized to meet the unique needs of every patient.
            </p>
          </div>
          <div className="flex flex-col md:flex-row items-start justify-between">
            <div className="md:w-1/2 mb-8 md:mb-0">
              <Image
                src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
                alt="Healthcare professionals examining medical scans"
                width={600}
                height={400}
                className="rounded-lg shadow-lg w-full object-cover"
              />
            </div>
            <div className="md:w-1/2 md:pl-12">
              <div className="mb-8">
                <h2 className="text-2xl font-semibold mb-4 text-blue-700">Our Mission</h2>
                <p className="text-gray-700">
                  At Willkings Healthcare, we are committed to improving the health and well-being of our community through innovative products and compassionate care.
                </p>
              </div>
              <div className="mb-8">
                <h2 className="text-2xl font-semibold mb-4 text-blue-700">Our Vision</h2>
                <p className="text-gray-700">
                  To be the leading provider of healthcare solutions, empowering individuals to lead healthier, happier lives.
                </p>
              </div>
              <div>
                <h2 className="text-2xl font-semibold mb-4 text-blue-700">Our Services</h2>
                <ul className="list-disc list-inside text-gray-700">
                  <li>High-quality medical products</li>
                  <li>Expert healthcare consultations</li>
                  <li>Personalized wellness programs</li>
                  <li>24/7 customer support</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

