import Image from 'next/image'

const products = [
  { name: 'Advanced Heart Monitor', image: '/placeholder.svg', description: 'State-of-the-art heart monitoring device for accurate and continuous cardiac health tracking.' },
  { name: 'Smart Blood Pressure Cuff', image: '/placeholder.svg', description: 'Wireless blood pressure monitor with smartphone integration for easy tracking and analysis.' },
  { name: 'Portable Oxygen Concentrator', image: '/placeholder.svg', description: 'Lightweight and efficient oxygen therapy device for patients with respiratory conditions.' },
  { name: 'Digital Thermometer', image: '/placeholder.svg', description: 'Fast and precise temperature measurement with a large, easy-to-read display.' },
  { name: 'Adjustable Hospital Bed', image: '/placeholder.svg', description: 'Comfortable and versatile hospital bed with electric adjustments for optimal patient care.' },
  { name: 'Wheelchair', image: '/placeholder.svg', description: 'Durable and lightweight wheelchair designed for maximum comfort and mobility.' },
]

export default function Products() {
  return (
    <div 
      className="min-h-screen bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: 'url("https://hebbkx1anhila5yf.public.blob.vercel-storage.com/modified_background_image-35EBmw390qldclCP6hj3LNxPPOC6I1.png")',
      }}
    >
      <div className="container mx-auto px-6 py-12">
        <div className="bg-white/95 backdrop-blur-sm rounded-lg shadow-md p-8">
          <h1 className="text-4xl font-bold mb-8 text-center text-blue-800">Our Products</h1>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.map((product, index) => (
              <div key={index} className="bg-gray-50/80 backdrop-blur-sm rounded-lg shadow-md overflow-hidden">
                <Image
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  width={400}
                  height={300}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h2 className="text-xl font-semibold mb-2 text-blue-700">{product.name}</h2>
                  <p className="text-gray-600">{product.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

