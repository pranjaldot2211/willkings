/*
import Image from 'next/image'

const teamMembers = [
  { name: 'Dr. Sarah Johnson', position: 'Medical Director', bio: 'Dr. Johnson has over 15 years of experience in internal medicine and healthcare management.' },
  { name: 'Michael Chen', position: 'Chief Technology Officer', bio: 'With a background in biomedical engineering, Michael leads our product development team.' },
  { name: 'Emily Rodriguez', position: 'Head of Human Resources', bio: 'Emily ensures our team is well-supported and aligned with our mission and values.' },
  { name: 'David Kim', position: 'Chief Financial Officer', bio: 'David brings 20 years of financial expertise to manage our company\'s growth and sustainability.' },
]

export default function About() {
  return (
    <div 
      className="min-h-screen bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: 'url("https://hebbkx1anhila5yf.public.blob.vercel-storage.com/modified_background_image-35EBmw390qldclCP6hj3LNxPPOC6I1.png")',
      }}
    >
      <div className="container mx-auto px-6 py-12">
        <div className="bg-white/95 backdrop-blur-sm rounded-lg shadow-md p-8">
          <h1 className="text-4xl font-bold mb-8 text-center text-blue-800">About Us</h1>
          <p className="text-xl mb-12 text-center text-gray-600">
            At Willkings HealthCare, our team of dedicated professionals is committed to improving lives through innovative healthcare solutions.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {teamMembers.map((member, index) => (
              <div key={index} className="bg-gray-50/80 backdrop-blur-sm rounded-lg shadow-md overflow-hidden flex">
                <Image
                  src="/placeholder.svg"
                  alt={member.name}
                  width={150}
                  height={150}
                  className="w-1/3 object-cover"
                />
                <div className="p-6 w-2/3">
                  <h2 className="text-xl font-semibold mb-2 text-blue-700">{member.name}</h2>
                  <h3 className="text-lg text-gray-600 mb-2">{member.position}</h3>
                  <p className="text-gray-600">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
*/

// Temporary placeholder
export default function About() {
  return null;
}

