import Link from 'next/link'
import Image from 'next/image'

export default function Header() {
  return (
    <header className="bg-white shadow-md">
      <nav className="container mx-auto px-6 py-3">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-01-14%20at%2019.14.47_3a7febc5.jpg-f4lR5O7Dg0s6It83rUDALHXBG2uRi5.jpeg"
              alt="Willkings Healthcare Logo"
              width={300}
              height={150}
              className="h-24 w-auto object-contain"
              priority
            />
          </Link>
          <ul className="flex space-x-6">
            <li><Link href="/" className="text-blue-600 hover:text-blue-800">Home</Link></li>
            <li><Link href="/products" className="text-blue-600 hover:text-blue-800">Products</Link></li>
            {/* <li><Link href="/about" className="text-blue-600 hover:text-blue-800">About Us</Link></li> */}
            <li><Link href="/contact" className="text-blue-600 hover:text-blue-800">Contact Us</Link></li>
          </ul>
        </div>
      </nav>
    </header>
  )
}

