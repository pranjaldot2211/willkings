# About Us

At WellKings Health Care, our team of dedicated professionals is committed to improving lives through innovative healthcare solutions.

## Our Team

### Dr. Sarah Johnson - Medical Director
Dr. Johnson has over 15 years of experience in internal medicine and healthcare management.

### Michael Chen - Chief Technology Officer
With a background in biomedical engineering, Michael leads our product development team.

### Emily Rodriguez - Head of Human Resources
Emily ensures our team is well-supported and aligned with our mission and values.

### David Kim - Chief Financial Officer
David brings 20 years of financial expertise to manage our company's growth and sustainability.

