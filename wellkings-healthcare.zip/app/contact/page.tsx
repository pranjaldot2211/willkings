import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

export default function Contact() {
  return (
    <div 
      className="min-h-screen bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: 'url("https://hebbkx1anhila5yf.public.blob.vercel-storage.com/modified_background_image-35EBmw390qldclCP6hj3LNxPPOC6I1.png")',
      }}
    >
      <div className="container mx-auto px-6 py-12">
        <div className="bg-white/95 backdrop-blur-sm rounded-lg shadow-md p-8">
          <h1 className="text-4xl font-bold mb-8 text-center text-blue-800">Contact Us</h1>
          <div className="max-w-2xl mx-auto">
            <div className="bg-gray-50/80 backdrop-blur-sm rounded-lg shadow-md p-6 mb-8">
              <h2 className="text-2xl font-semibold mb-4 text-blue-700">Company Information</h2>
              <p className="mb-2 text-gray-600"><strong>Address:</strong> Willkings healthcare pvt ltd, J1-604 Aangan, Adani Shantigram Township Nr. Vaishnodevi Circle, Ahmedabad Gujarat-382421</p>
              <p className="mb-2 text-gray-600"><strong>Email:</strong> </p>
              <p className="mb-2 text-gray-600"><strong>Phone:</strong> </p>
            </div>
            <div className="bg-gray-50/80 backdrop-blur-sm rounded-lg shadow-md p-6">
              <h2 className="text-2xl font-semibold mb-4 text-blue-700">Send us a message</h2>
              <form>
                <div className="mb-4">
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                  <Input type="text" id="name" name="name" required />
                </div>
                <div className="mb-4">
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                  <Input type="email" id="email" name="email" required />
                </div>
                <div className="mb-4">
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">Message</label>
                  <Textarea id="message" name="message" rows={4} required />
                </div>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white">Send Message</Button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

